from langchain_community.document_loaders.college_confidential import (
    CollegeConfidentialLoader,
)

__all__ = ["CollegeConfidentialLoader"]
