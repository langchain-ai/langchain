from langchain_community.document_loaders.mongodb import MongodbLoader

__all__ = ["MongodbLoader"]
