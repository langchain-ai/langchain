from langchain_community.document_loaders.facebook_chat import (
    FacebookChatLoader,
    concatenate_rows,
)

__all__ = ["concatenate_rows", "FacebookChatLoader"]
